﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HW1Q5
{
    public partial class BankAccount : System.Web.UI.Page
    {
         decimal  savingsBalance = 30345.90m;
         decimal  checkingBalance = 40785.22m;
         decimal  studentBalance = 5643.23m;

        protected void Page_Load(object sender, EventArgs e)
        {
           

            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if(!IsPostBack)
            {             
                accountDropDown.Items.Add("Savings Account");
                accountDropDown.Items.Add("Checking Account");
                accountDropDown.Items.Add("Student Account");
            }

        }

        protected void withdrawButton_Click(object sender, EventArgs e)
        {
            decimal enteredAmount = decimal.Parse(withdrawlTextBox.Text);

            if (accountDropDown.SelectedIndex == 0)
            {
                if(enteredAmount <= savingsBalance)
                {
                    savingsBalance = savingsBalance - enteredAmount;
                    withdrawLabel.Text = "Withdrawl successful. Your new balance is "+savingsBalance.ToString("C");
                }
                else
                {
                    withdrawLabel.Text = "Withdrawl amount is greater than the balance which is "+ savingsBalance.ToString("C"); 
                }
            }
            else if(accountDropDown.SelectedIndex == 1)
            {
                if (enteredAmount <= checkingBalance)
                {
                    checkingBalance = checkingBalance - enteredAmount;
                    withdrawLabel.Text = "Withdrawl successful. Your new balance is " + checkingBalance.ToString("C");
                }
                else
                {
                    withdrawLabel.Text = "Withdrawl amount is greater than the balance which is " + checkingBalance.ToString("C");
                }
            }
            else
            {
                if (enteredAmount <= studentBalance)
                {
                    studentBalance = studentBalance - enteredAmount;
                    withdrawLabel.Text = "Withdrawl successful. Your new balance is " + studentBalance.ToString("C");
                }
                else
                {
                    withdrawLabel.Text = "Withdrawl amount is greater than the balance which is " + studentBalance.ToString("C");
                }
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Assign2.MyClasses;

namespace Assign2
{
    public partial class AccountSummary : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            GenericSessionObjects sessionObjs = new GenericSessionObjects();
            List<Account> acctList = (List<Account>)Session["AllAccounts"];
            Customer cust = (Customer)Session["customer"];

            NameLabel.Text = "Welcome " + cust.FullName;
            foreach(Account acct in acctList)
            {
                AccountListbox.Items.Add(acct.Nickname);
            }
        }

        protected void DetailsButton_Click(object sender, EventArgs e)
        {
            Server.Transfer("./AccountPages/AccountDetails.aspx");
        }
    }
}
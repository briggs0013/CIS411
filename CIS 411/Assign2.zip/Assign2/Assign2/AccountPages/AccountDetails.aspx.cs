﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Assign2.MyClasses;

namespace Assign2.AccountPages
{
    public partial class AccountDetails : System.Web.UI.Page
    {
        private static double currentBalance;

        protected void Page_Load(object sender, EventArgs e)
        {
            Session["currentBalance"] = currentBalance;
            List<Account> allAccounts = (List<Account>)Session["AllAccounts"];
            Customer cust = (Customer)Session["customer"];
            if (PreviousPage != null)
            {
                string url = PreviousPage.ToString();

                if (url.Contains("summary"))
                {
                    updateBalance();

                    int selectedIndex = ((ListBox)PreviousPage.FindControl("AccountListBox")).SelectedIndex;

                    Account selectedAccount = allAccounts[selectedIndex];
                    AccountNameLabel.Text = selectedAccount.Nickname;
                    AcctTypeLabel.Text = selectedAccount.Type;
                    BalanceLabel.Text = selectedAccount.Balance.ToString();
                    LoanLabel.Text = selectedAccount.hasLoanOffer().ToString();
                    AddressLabel.Text = cust.FullAddress;
                    currentBalance = selectedAccount.Balance;
                }



                else if (url.Contains("loan"))
                {
                    LoanLabel.Text = "came from loan";

                    double newBalance = (double)(Session["currentBalance"]);
                    BalanceLabel.Text = newBalance.ToString("c");

                    string name = (String)(Session["name"]);
                    string type = (String)(Session["type"]);
                    string loan = (String)(Session["loan"]);
                    string addr = (String)(Session["addr"]);

                    AccountNameLabel.Text = name;
                    AcctTypeLabel.Text = type;
                    LoanLabel.Text = loan;
                    AddressLabel.Text = addr;
                }
               
            }
                

        }

        protected void WithdrawMoneyButton_Click(object sender, EventArgs e)
        {
            WithdrawErrorLabel.Text = "";
            

            double withdrawRequest;
            double.TryParse(WithdrawTextBox.Text, out withdrawRequest);

            if (withdrawRequest < currentBalance)
            {
                currentBalance -= withdrawRequest;


                WithdrawErrorLabel.Text = withdrawRequest.ToString("c") + " withdrawn. Check new balance.";
                updateBalance();
            }
            else
            {


                WithdrawErrorLabel.Text = withdrawRequest.ToString("c") + " requested. Please enter a value less than balance.";
            }
        }
        public void updateBalance()
        {
            Session["currentbalance"] = currentBalance;
            BalanceLabel.Text = currentBalance.ToString("c");
        }

        protected void LoanButton_Click(object sender, EventArgs e)
        {
            Server.Transfer("./LoanApplicationPage.aspx");
        }
    }
}
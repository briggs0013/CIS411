﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Assign2.MyClasses;

namespace Assign2.AccountPages
{
    public partial class LoanApplicationPage : System.Web.UI.Page
    {
        private static double existingBalance;
        protected void Page_Load(object sender, EventArgs e)
        {
            double currentBalance = (double)(Session["currentBalance"]);
            existingBalance = currentBalance;

            if (PreviousPage != null)
            {
                Customer cust = (Customer)Session["customer"];
                NameLabel.Text = cust.FullName;
            }
        }

        protected void SubmitButton_Click(object sender, EventArgs e)
        {
            if (LoanApproval())
            {
                LoanApprovalLabel.Text = "Congratulations!!Your loan is approved";

            }
            else
            {
                LoanApprovalLabel.Text = "Your loan is not approved. Sorry!!";
            }
        }
        public Boolean LoanApproval()
        {
            double salary;
            double age;
            double loanamount;

            double.TryParse(SalaryTextBox.Text, out salary);       
            double.TryParse(AgeTextBox.Text, out age);        
            double.TryParse(LoanAmountTextBox.Text, out loanamount);
            double LoanCriteriaFormula = 0.5 * salary;

            if (age >18 && loanamount < existingBalance && loanamount < LoanCriteriaFormula)
            {
                return true;

            }
            else
            {
                return false;
            }
        }

        protected void GoToAcctSumButton_Click(object sender, EventArgs e)
        {
            Server.Transfer("/AccountSummary.aspx");

        }

      

       
    }
}
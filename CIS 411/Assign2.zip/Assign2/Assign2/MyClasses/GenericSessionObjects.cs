﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assign2.MyClasses
{
    public class GenericSessionObjects
    {
        List<Account> allAccounts = new List<Account>();

        public GenericSessionObjects()
        {
            Account ac1 = new Account();
            ac1.Type = "Checking";
            ac1.Balance = 30123.45;
            ac1.Nickname = "My chk1";

            Account ac2 = new Account();
            ac2.Type = "Checking";
            ac2.Balance = 20123.45;
            ac2.Nickname = "My chk2";

            Account ac3 = new Account();
            ac3.Type = "Saving";
            ac3.Balance = 22675.98;
            ac3.Nickname = "My sav1";

            allAccounts.Add(ac1);
            allAccounts.Add(ac2);
            allAccounts.Add(ac3);

            Customer cust1 = new Customer("Daniel Bert", "1234 Louisville Lane, Louisville");
            HttpContext.Current.Session["customer"] = cust1;
            HttpContext.Current.Session["AllAccounts"] = allAccounts;

        }
    }
}
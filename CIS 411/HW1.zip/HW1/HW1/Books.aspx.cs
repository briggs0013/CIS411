﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HW1
{
    public partial class Books : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if(!IsPostBack)
            {
                bookDropDown.Items.Add("Introduction to MIS");
                bookDropDown.Items.Add("Introduction to Marketing");
                bookDropDown.Items.Add("Introduction to Finance");
            }
        }

        protected void purchaseButton_Click(object sender, EventArgs e)
        {
            string selectedBook = bookDropDown.SelectedItem.Text;
            bookLabel.Text = "You have selected " +quantityTextBox.Text+" "+ selectedBook + "."+" the price is: "+bookCost(selectedBook).ToString("C");
        }

        double bookCost(String bookType)
        {
            double selectedQuantity = double.Parse(quantityTextBox.Text);

            if (bookType.Equals("Introduction to MIS"))
            {
                return 20.00*selectedQuantity;
            }
            else if (bookType.Equals("Introduction to Marketing"))
            {
                return 30.00*selectedQuantity;
            }
            else
                return 40.00*selectedQuantity;
         
        }

        
    }
}